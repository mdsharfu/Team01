// Function to show the selected section and hide others
function showSection(sectionId) {
    document.querySelectorAll('.content div').forEach(div => div.classList.add('hidden'));
    document.getElementById(sectionId).classList.remove('hidden');
}

// Function to handle money transfer
function transferMoney() {
    let fromAccount = document.getElementById("fromAccount").value;
    let toAccount = document.getElementById("toAccount").value;
    let amount = document.getElementById("amount").value;

    if (fromAccount && toAccount && amount > 0) {
        alert(`Transfer Successful!\nFrom: ${fromAccount}\nTo: ${toAccount}\nAmount: $${amount}`);
    } else {
        alert("Please enter valid details.");
    }
}

// Function to handle withdrawals
function withdrawMoney() {
    let withdrawAmount = document.getElementById("withdrawAmount").value;
    if (withdrawAmount > 0) {
        alert(`You have successfully withdrawn $${withdrawAmount}.`);
    } else {
        alert("Please enter a valid amount.");
    }
}

// Function to handle deposits
function depositMoney() {
    let depositAmount = document.getElementById("depositAmount").value;
    if (depositAmount > 0) {
        alert(`You have successfully deposited $${depositAmount}.`);
    } else {
        alert("Please enter a valid amount.");
    }
}

// Function to update user details
function updateUserDetails() {
    let email = document.getElementById("updateEmail").value;
    let address = document.getElementById("updateAddress").value;
    let contact = document.getElementById("updateContact").value;

    if (email && address && contact) {
        alert("User details updated successfully!");
    } else {
        alert("Please fill all fields.");
    }
}

// Function to handle profile button click
function viewProfile() {
    alert("Redirecting to Profile Page...");
}

// Function to handle logout button click
function logout() {
    let confirmLogout = confirm("Are you sure you want to logout?");
    if (confirmLogout) {
        alert("Logging out...");
        window.location.href = "login.html"; // Redirect to login page
    }
}
